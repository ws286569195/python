import Vue from 'vue'
import VueRouter from 'vue-router'
import login from '@/components/page/login'
import home from '@/components/page/home'
import index from '@/components/page/index'
import read from '@/components/djgl/read'
import lead from '@/components/djgl/lead'
import write from '@/components/djgl/write'
import spgl from '@/components/xtgl/spgl'
import khgl from '@/components/xtgl/khgl'
Vue.use(VueRouter);

const router = new VueRouter({
  routes: [
    {
      path: '/',
      redirect: '/login',
      component: login
    },
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/home',
      name: 'home',
      component: home,
      meta: {
        requiresAuth: true
      },
      redirect: 'index',
      children:[
        {
          path: '/index',
          name: 'indix',
          component: index,
          meta: {
            requiresAuth: true
          },
        },
        {
          path: '/read',
          name: 'read',
          component: read,
          meta: {
            requiresAuth: true
          },
        },
        {
          path: '/lead',
          name: 'lead',
          component: lead,
          meta: {
            requiresAuth: true
          },
        },
        {
          path: '/write',
          name: 'write',
          component: write,
          meta: {
            requiresAuth: true
          },
        },
        {
          path: '/spgl',
          name: 'spgl',
          component: spgl,
          meta: {
            requiresAuth: true
          },
        },
        {
          path: '/khgl',
          name: 'khgl',
          component: khgl,
          meta: {
            requiresAuth: true
          },
        }
      ]
    }]
});
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requiresAuth)) {
    console.log("token" + localStorage.token);
    if (localStorage.getItem('Authorization')) {  // 获取当前的token是否存在
      console.log("token存在" + localStorage.getItem('Authorization'));
      next();
    } else {
        console.log("token不存在");
        next({
          path: '/login', // 将跳转的路由path作为参数，登录成功后跳转到该路由
          query: { redirect: to.fullPath }
      })
    }
  }
  else { // 如果不需要权限校验，直接进入路由界面
    next();
  }
});

export default router