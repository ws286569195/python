<template>
  <div>
    <div class="block">
      <el-image :src="src"style="height: 750px;width: 1200px;"></el-image>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
export default {
  data() {
    return {
      src:
        "https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg",
    };
  },
};
</script>