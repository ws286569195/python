<template>
  <div>
    单据读入
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    data(){
      return {}
    }
  }
</script>