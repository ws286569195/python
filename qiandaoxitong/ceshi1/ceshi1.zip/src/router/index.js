import Vue from 'vue'
import VueRouter from 'vue-router'
import khgl from '@/components/khgl'
Vue.use(VueRouter);

const router = new VueRouter({
  routes: [
    {
      path: '/',
      redirect: 'khgl',
      component: khgl
    },
    ]
});


export default router