from flask import Flask, request, jsonify
from flask_cors import CORS
import pymysql

app = Flask("my-app")
CORS(app, resources=r'/*')

@app.route('/', methods=['POST'])
def hello_world():
    with DB(host='47.240.87.56', user='123', passwd='AHbTSiAYZMhG3jPy', db='test') as db:
        sql = "select * from userinfo"
        rows_count = db.execute(sql)
        if rows_count > 0:
            res = db.fetchall()
            return jsonify(res), 200
    return 'Hello World!'


@app.route('/add', methods=['POST'])
def add():
    print(request.headers)
    print(type(request.json))
    print(request.json)
    result = request.json['a'] + request.json['b']
    return str(result)
@app.route('/research', methods=['post'])  # 提供查询接口
def research():
    print(request.headers)
    code = request.json.get('code')
    with DB(host='www.ted1988.com', user='123', passwd='AHbTSiAYZMhG3jPy', db='test') as db:
        if code == "001":
            sql = "select * from userinfo"
            rows_count = db.execute(sql)
            if rows_count > 0:
                res = db.fetchall()
                return jsonify(res), 200
        elif code == "002":  # 增加客户信息
            number =request.json.get('number')
            sql = "select * from userinfo where number = '%s'" % number
            print(sql)
            rows_count = db.execute(sql)
            if rows_count > 0:
                res = db.fetchall()
                return jsonify(res), 200
            else:
                return jsonify(msg='004'), 200
        elif code == "003":  # 删除客户信息
            print(request.json.get('data'))
            data = request.json.get('data')
            print(len(data))
            if len(data) == 1:
                sql = "delete from clientinfo where id = %s" % str(
                    data[0]["ID"])
                print(sql)
            else:
                sql = "delete from clientinfo where id in ("
                index = 1
                a = ""
                for item in data:
                    a = a + str(item["ID"])
                    if index < len(data):
                        a = a+","
                        index += 1
                sql = sql + a + ")"
                print(sql)
            try:
                # 执行sql语句
                db.execute(sql)
                # 提交到数据库执行
                return jsonify(msg="删除成功"), 200

            except:
                # 发生错误时回滚
                # db.rollback()
                return jsonify(msg="删除失败"), 200
        elif code == "004":  # 修改客户信息
            print(request.json.get('data'))
            data = request.json.get('data')
            null = 'null'
            data = request.json.get('data')
            clientname = "'" + str(data['clientname']) + "'"
            if data['clienttax'] == None:
                clienttax = null
            else:
                clienttax = "'" + str(data['clienttax']) + "'"
            if data['clientaddress'] == None:
                clientaddress = null
            else:
                clientaddress = "'" + str(data['clientaddress']) + "'"
            if data['clientphone'] == None:
                clientphone = null
            else:
                clientphone = "'" + str(data['clientphone']) + "'"
            if data['clientbank'] == None:
                clientbank = null
            else:
                clientbank = "'" + str(data['clientbank']) + "'"
            if data['clientbankno'] == None:
                clientbankno = null
            else:
                clientbankno = "'" + str(data['clientbankno']) + "'"
            sql = "update clientinfo set clientname=%s,clienttax=%s,clientaddress=%s,clientphone=%s,clientbank=%s,clientbankno=%s where id=%d" % (
                clientname, clienttax, clientaddress, clientphone, clientbank, clientbankno, data["ID"])
            try:
                # 执行sql语句
                db.execute(sql)
                # 提交到数据库执行
                # print(request.json.get('data'))
                return jsonify(msg="修改成功"), 200
            except:
                # 发生错误时回滚
                # db.rollback()
                return jsonify(msg="修改失败"), 200



class DB():
    def __init__(self, host='47.240.87.56', port=3306, db='', user='root', passwd='AHbTSiAYZMhG3jPy', charset='utf8'):
        # 建立连接
        self.conn = pymysql.connect(
            host=host, port=port, db=db, user=user, passwd=passwd, charset=charset)
        # 创建游标，操作设置为字典类型
        self.cur = self.conn.cursor(cursor=pymysql.cursors.DictCursor)

    def __enter__(self):
        # 返回游标
        return self.cur

    def __exit__(self, exc_type, exc_val, exc_tb):
        # 提交数据库并执行
        self.conn.commit()
        # 关闭游标
        self.cur.close()
        # 关闭数据库连接
        self.conn.close()

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
