import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import axios from "axios"
import store from './store'
import Vuex from 'vuex'
Vue.prototype.$axios = axios;
Vue.config.productionTip = false
/* eslint-disable no-new */
Vue.use(ElementUI)
Vue.use(Vuex);
axios.defaults.baseURL = 'http://127.0.0.1:5000'
axios.defaults.auth = {
  username: '',
  password: '',
}
axios.interceptors.request.use(
  config => {
    if (localStorage.getItem('Authorization')) {
      config.headers.authorization = localStorage.getItem('Authorization');
      // alert(localStorage.getItem('Authorization'));
    }

    return config;
  },
  error => {
    return Promise.reject(error);
  });
new Vue({
  el: '#app',
  router,
  store: store,
  components: { App },
  template: '<App/>'
})
