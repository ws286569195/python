<template>
  <div class="hello">
    <!-- <img src="../../assets/back.jpg" height="609" width="960"> -->
    <div id="app1" class="app1">
      <el-form ref="loginForm" :model="loginForm" label-width="80px">
        <el-form-item label="账号：">
          <div class="form-username">
            <el-input v-model="loginForm.username" style="width:200px"></el-input>
          </div>
        </el-form-item>
        <el-form-item label="密码：">
          <div class="form-username">
            <el-input v-model="loginForm.password" style="width:200px"></el-input>
          </div>
        </el-form-item>
        <el-form-item>
          <div class="form-username">
            <el-button type="primary" @click="login()">提交数据</el-button>
            <el-button>取消</el-button>
          </div>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template> 
<script>
import axios from "axios";
import { mapMutations } from "vuex";
export default {
  name: "login",
  data() {
    return {
      loginForm: {
        username: "",
        password: "",
      },
    };
  },
  methods: {
    onSubmit: function () {
      alert("提交数据！");
    },
    ...mapMutations(["changeLogin"]),
    login() {
      let _this = this;

      /////判读账号密码是否输入，没有则alert 出来
      if (this.loginForm.username === "" || this.loginForm.password === "") {
        alert("账号或密码不能为空");
      } else {
        // alert(_this.loginForm['username'])
        axios({
          method: "post",
          url: "/api/login",
          data: _this.loginForm,
        })
          .then((res) => {
            console.log(res.data);
            _this.userToken = "Bearer " + res.data["access_token"];

            // 将用户token保存到vuex中
            _this.changeLogin({
              Authorization: _this.userToken,
            });
            _this.$router.push("/home");
            alert("登陆成功");
          })
          .catch((error) => {
            alert("账号或密码错误");
            console.log(error);
          });
      }
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1,
h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.form-username {
  text-align: left;
}
.app1 {
  position: absolute;
  top: 40%;
  left: 40%;
  margin-left: -50px;
  margin-top: -50px;
}
.hello{
  margin-top: 100px;
}
</style>
