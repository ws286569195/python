<template>
  <div class="home">
    <el-container>
      <!--      <Header/>-->
      <!--      <el-main>首页</el-main>-->
      <el-button @click="exit">退出登录</el-button>
      <el-button @click="test">携带token的测试请求</el-button>
    </el-container>
  </div>
</template>

<script>
// @ is an alias to /src
import home from "@/components/page/home.vue";
import Axios from 'axios';
export default {
  name: "home",
  components: {
    home,
  },
  methods: {
    exit() {
      //退出登录，清空token
      localStorage.removeItem("Authorization");
      this.$router.push("/login");
      alert("您已成功退出系统！");
    },
    test() {
      Axios({
        method: "post",
        url: "/protected",
        data: { firstName: 'Fred', lastName: 'Flintstone' },
        // headers: {
        //   "Content-Type": "application/json",
        //   "Authorization": localStorage.getItem("Authorization"),
        // },
        // headers: {
        //   'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
        // },
      })
        .then(function (res) {
          // alert(localStorage.getItem('Authorization'));
          console.log("res", res);
        })
        .catch(function (err) {
          // alert(localStorage.getItem("Authorization"));
          console.log("err", err);
          
        });
    },
  },
};
</script>
<style>
</style>