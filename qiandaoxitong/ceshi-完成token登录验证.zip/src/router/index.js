import Vue from 'vue'
import VueRouter from 'vue-router'
import login from '@/components/page/login'
import home from '@/components/page/home'

Vue.use(VueRouter);

const router = new VueRouter({
  routes: [
    {
      path: '/',
      redirect: '/login',
      component: login
    },
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/home',
      name: 'home',
      component: home,
      meta: {
        requiresAuth: true
      },
    }]
});
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requiresAuth)) {
    console.log("token" + localStorage.token);
    if (localStorage.getItem('Authorization')) {  // 获取当前的token是否存在
      console.log("token存在" + localStorage.getItem('Authorization'));
      next();
    } else {
        console.log("token不存在");
        next({
          path: '/login', // 将跳转的路由path作为参数，登录成功后跳转到该路由
          query: { redirect: to.fullPath }
      })
    }
  }
  else { // 如果不需要权限校验，直接进入路由界面
    next();
  }
});

export default router