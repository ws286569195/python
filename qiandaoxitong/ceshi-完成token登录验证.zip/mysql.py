import pymysql
from flask import Flask,request,jsonify
from flask_cors import CORS
import json
from flask_jwt_extended import (
    JWTManager, jwt_required, create_access_token,
    get_jwt_identity
)
app = Flask(__name__)
CORS(app,resources=r'/*')

app.config['JWT_SECRET_KEY'] = 'super-secret'  # token私钥
jwt = JWTManager(app)

@app.route('/')
def hello_world():
   return ""

@app.route("/api/login", methods=['POST'])#登录判断，成功返回token
def form_args():
    print(request.headers)
    print(request.json.get('username'))
    username=request.json.get('username')
    password=request.json.get('password')
    with DB(host='127.0.0.1',user='root',passwd='root',db='test') as db:
        sql="select * from userinfo where username='%s'"% username
        rows_count = db.execute(sql)
        print(password)
        if rows_count >0:
            for i in db:
                print(i['username']+"__"+i['password'])
                if password==i['password']:
                    access_token = create_access_token(username)
                    return jsonify(access_token=access_token,msg="登录成功"), 200
                else:
                    print ("密码不匹配")
                    return jsonify(msg="密码错误"), 400
        else:
            print ("未找到用户名")
            return jsonify(msg="用户名错误错误"), 400
            

@app.route('/protected', methods=['post'])#带token验证的路由
@jwt_required
def protected():
    print(request.headers)
    return jsonify({'hello': 'world'}), 200

class DB():
    def __init__(self, host='localhost', port=3306, db='', user='root', passwd='root', charset='utf8'):
        # 建立连接 
        self.conn = pymysql.connect(host=host, port=port, db=db, user=user, passwd=passwd, charset=charset)
        # 创建游标，操作设置为字典类型        
        self.cur = self.conn.cursor(cursor = pymysql.cursors.DictCursor)

    def __enter__(self):
        # 返回游标        
        return self.cur

    def __exit__(self, exc_type, exc_val, exc_tb):
        # 提交数据库并执行        
        self.conn.commit()
        # 关闭游标        
        self.cur.close()
        # 关闭数据库连接        
        self.conn.close()
if __name__ == '__main__':
    app.run()
